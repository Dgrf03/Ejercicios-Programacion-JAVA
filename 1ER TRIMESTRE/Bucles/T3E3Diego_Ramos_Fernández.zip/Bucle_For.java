/************************************************************************       
 * Bucle_For.java
 * Programa que utiliza un bucle for para contar hasta 10.
 * Autor: Diego Ramos Fernández
 * Fecha: 07/10/2025
 * Curso: 1º DAM
 ************************************************************************/
public class Bucle_For {
    public static void main(String[] args) {
        for (int i = 1; i <= 1000000; i++) {
            System.out.print(+ i + ", ");
        }
    }
}