public class Numeros_Pares {
    public static void main(String[] args) {
        System.out.println("Números pares del 1 al 100:");
        for (int i = 1; i <= 100; i++) {
            if (i % 2 == 0) {
                System.out.println(i);
            }
        }
    }
}
