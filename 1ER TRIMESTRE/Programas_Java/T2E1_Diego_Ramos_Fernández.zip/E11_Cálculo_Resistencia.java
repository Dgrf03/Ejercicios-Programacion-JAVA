/************************************************************************       
 * E11_Cálculo_Resistencia.java
 * Este programa debe calcular el valor de la resistencia equivalente en paralelo de otras dos resistencias previamente informadas. Req=(R1*R2)/(R1+R2)
 * Autor: Diego Ramos Fernández
 * Fecha: 25/09/2025
 * Curso: 1º DAM
 ************************************************************************/
public class E11_Cálculo_Resistencia {
    public static void main(String[] args) {
        double R1 = 100.0; // Valor de la primera resistencia 
        double R2 = 200.0; // Valor de la segunda resistencia

        // Cálculo de la resistencia equivalente en paralelo
        double Req = (R1 * R2) / (R1 + R2);

        System.out.println("La resistencia equivalente en paralelo de " + R1 + " y " + R2 + " es: " + Req + " ohmios.");
    }
}