public class  E2_Variables {
    public static void main(String[] args) {
        int entero1 = 5;// Declaración e inicialización de una variable
        int entero2 = 10, entero3 = 15; // Declaración múltiple de variables del mismo tipo
        int entero4; // Declaración sin inicialización
        entero4 = 20; // Inicialización posterior

        System.out.println(entero1);
        System.out.println(entero2);
        System.out.println(entero3);
        System.out.println(entero4);

        byte b1 = 127; // Declaración e inicialización de una variable byte maximo valor
        byte b2 = -128; // Declaración e inicialización de una variable byte minimo valor
        byte b3 = 100; // Declaración e inicialización de una variable byte
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);

        short s1 = 32767; // Declaración e inicialización de una variable short maximo valor
        short s2 = -32768; // Declaración e inicialización de una variable short minimo valor
        System.out.println(s1);
        System.out.println(s2);

        long l1 = 10000000L; // Declaración e inicialización de una variable long 
        long l2 = -10000000L; // Declaración e inicialización de una variable long 
        System.out.println(l1);
        System.out.println(l2);

        double doble1 = 3;
        double doble2 = 3.14;
        double doble3 = 2.5e3; // 2.5 por 10 a la 3
        System.out.println(doble1);
        System.out.println(doble2); 
        System.out.println(doble3);

        float real1 = 3.14f; // Declaración e inicialización de una variable float
        System.out.println(real1);

        boolean bool1 = true; // Declaración e inicialización de una variable boolean
        boolean bool2 = false; // Declaración e inicialización de una variable boolean
        System.out.println(bool1);
        System.out.println(bool2);

        char caracter1 = 'a'; // Declaración e inicialización de una variable char minuscula
        char caracter2;
        caracter2 = 'A'; // Declaración e inicialización de una variable char mayuscula
        System.out.println(caracter1);
        System.out.println(caracter2);

        String frase1 = "Hola"; // Declaración e inicialización de una variable String
        String frase2;
        frase2 = "Me llamo Diego"; // Declaración e inicialización de una variable String

        System.out.println(frase1);
        System.out.println(frase2);
        System.out.println("Me gusta el bocata de tortilla de patata con jamón serrano.");
    }
}
