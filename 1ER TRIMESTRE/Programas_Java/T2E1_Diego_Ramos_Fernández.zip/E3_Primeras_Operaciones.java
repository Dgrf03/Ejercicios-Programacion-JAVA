/************************************************************************       
 * E3_Primeras_Operaciones.java
 * Este programa realiza varias operaciones matemáticas básicas.
 * Autor: Diego Ramos Fernández
 * Fecha: 19/09/2025
 * Curso: 1º DAM
 ************************************************************************/


public class  E3_Primeras_Operaciones {
    public static void main(String[] args) {
        int a = 10; // Valor inicial de a
        int b = 5; // Valor inicial de b
        int suma = a + b; // Suma   
        int resta = a - b; // Resta
        int multiplicacion = a * b; // Multiplicación
        int division = a / b; // División entera
        int modulo = a % b; // Operador módulo
        //Mostrar resultados
        System.out.println("Suma: " + suma); // Suma
        System.out.println("Resta: " + resta); // Resta
        System.out.println("Multiplicación: " + multiplicacion); // Multiplicación
        System.out.println("División: " + division); // División entera
        System.out.println("Módulo: " + modulo); // Módulo
        
        a++; // Incremento
        b--; // Decremento 
        int sumaPost = a + b; // Suma después del incremento/decremento
        System.out.println("Suma después del incremento/decremento: " + sumaPost);
        int c = 3;
        int d = 4;
        int e = 6;
        int f = 8;
        //Calculo la media de c, d, e y f
        double media = (c + d + e + f) / 4.0;
        System.out.println("La media de " + c + ", " + d + ", " + e + " y " + f + " es: " + media);
        //Calcular el area de un cuadrado
        int lado = 5; // Cambia este valor para probar con otros números
        int areaCuadrado = lado * lado;
        System.out.println("El área de un cuadrado con lado " + lado + " es: " + areaCuadrado);
        //Calcular el area de un triangulo
        int base = 4; // Variable base
        int altura = 7; // Variable altura
        double areaTriangulo = (base * altura) / 2.0;
        System.out.println("El área de un triángulo con base " + base + " y altura " + altura + " es: " + areaTriangulo);
        
        //Si divido 23 entre 7, ¿cuál es el resultado, cociente y  el resto?
        int dividendo = 23;
        int divisor = 7;
        int cociente = dividendo / divisor;
        int resto = dividendo % divisor;
        double resultado = (double) dividendo / divisor; // Resultado de la división entera
        System.out.println("Dividiendo " + dividendo + " entre " + divisor + ":");
        System.out.println("Cociente: " + cociente);
        System.out.println("Resto: " + resto);
        System.out.println("Resultado: " + resultado);  
        //Ax +B=0
        int coeficienteA = 2; // Variable A
        int coeficienteB = 10; // Variable B
        //Resolviendo la ecuación
        double solucion = (double) -coeficienteB / coeficienteA;
        System.out.println("La solución de la ecuación " + coeficienteA + "x + " + coeficienteB + " = 0 es: " + solucion);

        //como elevar un numero a 7
        int numero = 3; // Variable número
        int resultadoElevado = (int) Math.pow(numero, 7);   
        System.out.println("El resultado de " + numero + " elevado a 7 es: " + resultadoElevado);   

        //Volumen de una esfera
        double radio = 6.0; // Variable radio
        double volumenEsfera = (4.0 / 3.0) * Math.PI * Math.pow(radio, 3);
        System.out.println("El volumen de una esfera con radio " + radio + " es: " + volumenEsfera);

    }
}
