/************************************************************************       
 * E4_Media_aritmética_y_geométrica.java
 * Este programa realiza la media aritmética y la media geométrica.
 * Autor: Diego Ramos Fernández
 * Fecha: 23/09/2025
 * Curso: 1º DAM
 ************************************************************************/


public class  E4_Media_aritmética_y_geométrica {
    public static void main(String[] args) {
        
        // Declaración de variables
        double numero1;
        double numero2;
        double mediaAritmetica;
        double mediaGeometrica;
        
        // Asignación de valores a las variables
        numero1 = 5.0;
        numero2 = 10.0;
        
        // Cálculo de la media aritmética
        mediaAritmetica = (numero1 + numero2) / 2;
        
        // Cálculo de la media geométrica
        mediaGeometrica = Math.sqrt(numero1 * numero2);
        
        // Mostrar
        System.out.println("La media aritmética de " + numero1 + " y " + numero2 + " es: " + mediaAritmetica);
        System.out.println("La media geométrica de " + numero1 + " y " + numero2 + " es: " + mediaGeometrica);
    }
}