/************************************************************************       
 * E5_Ecuación_2º_grado.java
 * Este programa realiza la ecuación de segundo grado.
 * Autor: Diego Ramos Fernández
 * Fecha: 23/09/2025
 * Curso: 1º DAM
 ************************************************************************/

 public class E5_Ecuación_2º_grado {
     public static void main(String[] args) {
         // Declaración de variables
         double a, b, c; // Coeficientes de la ecuación
         double discriminante, raiz1, raiz2; // Variables para el cálculo de las raíces

         // Asignación de valores a los coeficientes
         a = 1; // Coeficiente de x^2
         b = -3; // Coeficiente de x
         c = 2; // Término independiente

         // Cálculo del discriminante
         discriminante = b * b - 4 * a * c;

         // Comprobación del valor del discriminante y cálculo de las raíces
         if (discriminante > 0) {
             // Dos raíces reales y distintas
             raiz1 = (-b + Math.sqrt(discriminante)) / (2 * a);
             raiz2 = (-b - Math.sqrt(discriminante)) / (2 * a);
             System.out.println("Las raíces son reales y distintas:");
             System.out.println("Raíz 1: " + raiz1);
             System.out.println("Raíz 2: " + raiz2);
         } else if (discriminante == 0) {
             // Una raíz real doble
             raiz1 = -b / (2 * a);
             System.out.println("La raíz es real y doble:");
             System.out.println("Raíz: " + raiz1);
         } else {
             // No hay raíces reales
             System.out.println("No hay raíces reales.");
         }
     }
 }