/************************************************************************       
 * E6_Valores_Con_if.java
 * Este programa muestra como utilizar la estructura if y else.
 * Autor: Diego Ramos Fernández
 * Fecha: 24/09/2025
 * Curso: 1º DAM
 ************************************************************************/


public class E6_Valores_Con_if {
    public static void main(String[] args) {
        int x = 1000; // Puedes cambiar este valor para probar diferentes casos
        System.out.println("El valor de x es: " + x);
        // Primer if para comprobar si el número es mayor o igual que 100
        if (x >= 100) {
            System.out.println("El número " + x + " es mayor o igual que 100.");
        }

        // Segundo if para comprobar si el número es par
        if (x % 2 == 0) {
            System.out.println("El número " + x + " es par.");
        } else {
            System.out.println("El número " + x + " es impar.");
        }
    }
}
