/************************************************************************       
 * E8_Intercambio_De_Valores.java
 * Este programa debe intercambiar el valor de dos variables.Ejemplo: Si X = 1 e Y = 2, al finalizar el programa los valores deben ser X = 2 e Y = 1. 
 * Autor: Diego Ramos Fernández
 * Fecha: 25/09/2025
 * Curso: 1º DAM
 ************************************************************************/
public class E8_Intercambio_De_Valores {
    public static void main(String[] args) {
        int x = 5; // Valor inicial de x
        int y = 10; // Valor inicial de y

        System.out.println("Antes del intercambio:");
        System.out.println("x = " + x);
        System.out.println("y = " + y);

        // Intercambio de valores usando una variable temporal
        int temp = x; // Guardamos el valor de x en una variable temporal
        x = y; // Asignamos el valor de y a x
        y = temp; // Asignamos el valor guardado en temp (valor original de x) a y

        System.out.println("Después del intercambio:");
        System.out.println("x = " + x);
        System.out.println("y = " + y);
    }
}
