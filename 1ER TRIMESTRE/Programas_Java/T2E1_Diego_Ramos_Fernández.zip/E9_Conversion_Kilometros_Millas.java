/************************************************************************       
 * E9_Conversion_Kilometros_Millas.java
 * Este programa debe convertir una cantidad de km en sus millas equivalentes. 1 km = 0,621371 millas
 * Autor: Diego Ramos Fernández
 * Fecha: 25/09/2025
 * Curso: 1º DAM
 ************************************************************************/
public class E9_Conversion_Kilometros_Millas {
    public static void main(String[] args) {
        double km = 10.0; // Puedes cambiar este valor para probar diferentes casos
        double millas = km * 0.621371;
        System.out.println(km + " kilómetros son equivalentes a " + millas + " millas.");
    }
}