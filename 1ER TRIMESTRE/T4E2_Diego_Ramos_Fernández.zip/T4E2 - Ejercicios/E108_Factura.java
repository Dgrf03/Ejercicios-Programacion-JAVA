import java.util.Scanner;

public class E108_Factura {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Variables para acumular los totales
        double baseImponible = 0;
        double totalIVA = 0;
        int numeroLinea = 1;
        char continuar;
        
        System.out.println("*** CREAR FACTURA ***\n");
        
        do {
            System.out.println("--- Línea " + numeroLinea + " ---");
            
            // Pedir datos del producto
            System.out.print("Nombre del producto: ");
            sc.nextLine();
            String producto = sc.nextLine();
            
            System.out.print("Cantidad: ");
            int cantidad = sc.nextInt();
            
            System.out.print("Precio unitario: ");
            double precio = sc.nextDouble();
            
            System.out.println("Tipo de IVA:");
            System.out.println("1. Normal (21%)");
            System.out.println("2. Reducido (10%)");
            System.out.println("3. Superreducido (4%)");
            System.out.print("Elige opción: ");
            int tipoIVA = sc.nextInt();
            
            // Calcular el subtotal de esta línea
            double subtotal = cantidad * precio;
            double iva = 0;
            
            if (tipoIVA == 1) {
                iva = subtotal * 0.21;
            } else if (tipoIVA == 2) {
                iva = subtotal * 0.10;
            } else if (tipoIVA == 3) {
                iva = subtotal * 0.04;
            }
            
            double totalLinea = subtotal + iva;
            
            // Mostrar la línea introducida
            System.out.println("\nLínea añadida:");
            System.out.println(producto + " | Cantidad: " + cantidad + " | Precio: " + precio + " €");
            System.out.println("Subtotal: " + subtotal + " € | IVA: " + iva + " € | Total: " + totalLinea + " €\n");
            
            // Acumular en los totales generales
            baseImponible = baseImponible + subtotal;
            totalIVA = totalIVA + iva;
            
            // Preguntar si quiere añadir más líneas
            System.out.print("¿Quieres añadir otra línea? (s/n): ");
            continuar = sc.next().charAt(0);
            System.out.println();
            
            numeroLinea++;
            
        } while (continuar == 's' || continuar == 'S');
        
        // Calcular el total final
        double importeTotal = baseImponible + totalIVA;
        
        // Mostrar la factura completa
        System.out.println("\n========================================");
        System.out.println("          FACTURA FINAL");
        System.out.println("========================================");
        System.out.println("Base imponible (sin IVA): " + baseImponible + " €");
        System.out.println("IVA total: " + totalIVA + " €");
        System.out.println("----------------------------------------");
        System.out.println("IMPORTE TOTAL: " + importeTotal + " €");
        System.out.println("========================================");
        
        sc.close();
    }
}
