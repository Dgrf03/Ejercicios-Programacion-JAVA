import java.util.ArrayList;

public class Cliente extends Persona {

    private int numeroCliente;
    private ArrayList<String> tipoPermisoConducir; // A, B, C, D...

    public Cliente() {
        super();
        this.numeroCliente = 0;
        this.tipoPermisoConducir = new ArrayList<>();
    }

    public Cliente(String nombre, TipoDocumento tipoDocumento, String numeroDocumento, int numeroCliente, ArrayList<String> tipoPermisoConducir) {
        super(nombre, tipoDocumento, numeroDocumento);
        this.numeroCliente = numeroCliente;
        this.tipoPermisoConducir = tipoPermisoConducir;
    }

    public Cliente(Cliente c) {
        super(c);
        this.numeroCliente = c.numeroCliente;
        this.tipoPermisoConducir = new ArrayList<>(c.tipoPermisoConducir);
    }

    public int getNumeroCliente() { return numeroCliente; }
    public void setNumeroCliente(int numeroCliente) { this.numeroCliente = numeroCliente; }

    public ArrayList<String> getTipoPermisoConducir() { return tipoPermisoConducir; }
    public void setTipoPermisoConducir(ArrayList<String> tipoPermisoConducir) {
        this.tipoPermisoConducir = tipoPermisoConducir;
    }

    @Override
    public String toString() {
        return super.toString() + "\nNúmero cliente: " + numeroCliente + "\nTipos permiso conducir: " + tipoPermisoConducir;
    }

    @Override
    public boolean notificar(String mensaje) {
        System.out.println("Mensaje para el cliente: " + mensaje);
        return true;
    }
}
