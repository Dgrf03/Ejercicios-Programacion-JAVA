public class Coche extends Vehiculo implements Repostable {

    public enum TipoCoche {
        GASOLINA, DIESEL, HIBRIDO, ELECTRICO
    }

    private TipoCoche tipo;
    private int estado; // 0–10

    public Coche() {
        super();
        this.tipo = TipoCoche.GASOLINA;
        this.estado = 0;
    }

    public Coche(String matricula, String fechaMatriculacion, double capacidadTotal, double cargaActual, double precio, TipoCoche tipo, int estado) {
        super(matricula, fechaMatriculacion, capacidadTotal, cargaActual, precio);
        this.tipo = tipo;
        this.estado = estado;
    }

    public Coche(Coche c) {
        super(c);
        this.tipo = c.tipo;
        this.estado = c.estado;
    }

    public TipoCoche getTipo() { return tipo; }
    public void setTipo(TipoCoche tipo) { this.tipo = tipo; }

    public int getEstado() { return estado; }
    public void setEstado(int estado) { this.estado = estado; }

    @Override
    public String toString() {
        return super.toString() + "\nTipo coche: " + tipo + "\nEstado (0-10): " + estado;
    }

    @Override
    public void repostar(double dinero) {
        double cargaExtra = 0;

        switch (tipo) {
            case ELECTRICO:
                cargaExtra = dinero * 2.175;
                break;
            case GASOLINA:
                cargaExtra = dinero * 1.45;
                break;
            case DIESEL:
                cargaExtra = dinero * 1.25;
                break;
            case HIBRIDO:
                cargaExtra = dinero * ((1.45 + 2.175) / 2.0);
                break;
        }

        double nuevaCarga = getCargaActual() + cargaExtra;
        if (nuevaCarga > getCapacidadTotal()) {
            nuevaCarga = getCapacidadTotal();
        }
        setCargaActual(nuevaCarga);
    }
}
