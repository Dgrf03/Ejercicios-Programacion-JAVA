import java.util.Scanner;
import java.util.ArrayList;

public class Concesionario {

    private Cliente[] clientes;        // 3
    private Trabajador[] trabajadores; // 2
    private Vehiculo[] vehiculos;      // 6 (3 coches, 3 motos)

    public Concesionario() {
        this.clientes = new Cliente[3];
        this.trabajadores = new Trabajador[2];
        this.vehiculos = new Vehiculo[6];
    }

    public void leerClientes() {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < clientes.length; i++) {
            System.out.println("\nCliente " + (i + 1));
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Tipo documento (DNI/NIE/PAS): ");
            String tipoDocStr = sc.nextLine().toUpperCase();
            Persona.TipoDocumento tipoDoc = Persona.TipoDocumento.valueOf(tipoDocStr);

            System.out.print("Número documento: ");
            String numDoc = sc.nextLine();

            System.out.print("Número cliente: ");
            int numCliente = Integer.parseInt(sc.nextLine());

            System.out.print("Permisos (ej: A,B,C): ");
            String permisosStr = sc.nextLine();
            String[] partes = permisosStr.split(",");
            ArrayList<String> permisos = new ArrayList<>();
            for (String p : partes) {
                permisos.add(p.trim());
            }

            clientes[i] = new Cliente(nombre, tipoDoc, numDoc, numCliente, permisos);
        }
        sc.close();
    }

    public void leerTrabajadores() {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < trabajadores.length; i++) {
            System.out.println("\nTrabajador " + (i + 1));
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Tipo documento (DNI/NIE/PAS): ");
            String tipoDocStr = sc.nextLine().toUpperCase();
            Persona.TipoDocumento tipoDoc = Persona.TipoDocumento.valueOf(tipoDocStr);

            System.out.print("Número documento: ");
            String numDoc = sc.nextLine();

            System.out.print("Número S.S.: ");
            String numSS = sc.nextLine();

            System.out.print("Fecha antigüedad (dd/MM/yyyy): ");
            String fechaAnt = sc.nextLine();

            trabajadores[i] = new Trabajador(nombre, tipoDoc, numDoc, numSS, fechaAnt);

            sc.close();
        }
    }

    public void leerVehiculos() {
        Scanner sc = new Scanner(System.in);

        // 3 coches
        for (int i = 0; i < 3; i++) {
            System.out.println("\nCoche " + (i + 1));
            System.out.print("Matrícula: ");
            String matricula = sc.nextLine();

            System.out.print("Fecha matriculación: ");
            String fechaMat = sc.nextLine();

            System.out.print("Capacidad total: ");
            double capTotal = Double.parseDouble(sc.nextLine());

            System.out.print("Carga actual: ");
            double cargaAct = Double.parseDouble(sc.nextLine());

            System.out.print("Precio: ");
            double precio = Double.parseDouble(sc.nextLine());

            System.out.print("Tipo (GASOLINA/DIESEL/HIBRIDO/ELECTRICO): ");
            String tipoStr = sc.nextLine().toUpperCase();
            Coche.TipoCoche tipo = Coche.TipoCoche.valueOf(tipoStr);

            System.out.print("Estado (0-10): ");
            int estado = Integer.parseInt(sc.nextLine());

            vehiculos[i] = new Coche(matricula, fechaMat, capTotal, cargaAct, precio, tipo, estado);

            sc.close();
        }

        // 3 motos
        for (int i = 3; i < 6; i++) {
            System.out.println("\nMoto " + (i - 2));
            System.out.print("Matrícula: ");
            String matricula = sc.nextLine();

            System.out.print("Fecha matriculación: ");
            String fechaMat = sc.nextLine();

            System.out.print("Capacidad total: ");
            double capTotal = Double.parseDouble(sc.nextLine());

            System.out.print("Carga actual: ");
            double cargaAct = Double.parseDouble(sc.nextLine());

            System.out.print("Precio: ");
            double precio = Double.parseDouble(sc.nextLine());

            System.out.print("Cilindros: ");
            int cilindros = Integer.parseInt(sc.nextLine());

            System.out.print("CV: ");
            int cv = Integer.parseInt(sc.nextLine());

            vehiculos[i] = new Moto(matricula, fechaMat, capTotal, cargaAct, precio, cilindros, cv);
        }
    }

    public Vehiculo masBarato() {
        Vehiculo masBarato = null;
        for (Vehiculo v : vehiculos) {
            if (v == null) continue;
            if (masBarato == null || v.getPrecio() < masBarato.getPrecio()) {
                masBarato = v;
            }
        }
        return masBarato;
    }

    public Cliente[] getClientes() { return clientes; }
    public Trabajador[] getTrabajadores() { return trabajadores; }
    public Vehiculo[] getVehiculos() { return vehiculos; }
}