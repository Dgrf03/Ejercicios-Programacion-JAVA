public class Main {

    public static void main(String[] args) {

        Concesionario c = new Concesionario();

        // Ejemplo sin teclado (puedes cambiarlo por leerClientes/leerTrabajadores/leerVehiculos)

        java.util.ArrayList<String> permisos = new java.util.ArrayList<>();
        permisos.add("B");

        Cliente cli1 = new Cliente("Ana", Persona.TipoDocumento.DNI, "12345678A", 1, permisos);
        Cliente cli2 = new Cliente("Luis", Persona.TipoDocumento.NIE, "X1234567B", 2, permisos);
        Cliente cli3 = new Cliente("Marta", Persona.TipoDocumento.PAS, "P9876543", 3, permisos);

        Trabajador t1 = new Trabajador("Pedro", Persona.TipoDocumento.DNI, "22334455C", "12345678901", "01/01/2020");
        Trabajador t2 = new Trabajador("Laura", Persona.TipoDocumento.DNI, "33445566D", "10987654321", "15/03/2018");

        Coche coche1 = new Coche("1111AAA", "01/01/2020", 50, 10, 15000, Coche.TipoCoche.GASOLINA, 8);
        Coche coche2 = new Coche("2222BBB", "01/06/2021", 60, 5, 12000, Coche.TipoCoche.DIESEL, 7);
        Coche coche3 = new Coche("3333CCC", "01/03/2022", 70, 20, 18000, Coche.TipoCoche.ELECTRICO, 9);

        Moto moto1 = new Moto("4444DDD", "01/02/2019", 15, 5, 4000, 2, 50);
        Moto moto2 = new Moto("5555EEE", "01/07/2020", 18, 8, 3500, 2, 60);
        Moto moto3 = new Moto("6666FFF", "01/09/2021", 20, 10, 5000, 4, 80);

        c.getClientes()[0] = cli1;
        c.getClientes()[1] = cli2;
        c.getClientes()[2] = cli3;

        c.getTrabajadores()[0] = t1;
        c.getTrabajadores()[1] = t2;

        c.getVehiculos()[0] = coche1;
        c.getVehiculos()[1] = coche2;
        c.getVehiculos()[2] = coche3;
        c.getVehiculos()[3] = moto1;
        c.getVehiculos()[4] = moto2;
        c.getVehiculos()[5] = moto3;

        // masBarato()
        Vehiculo barato = c.masBarato();
        System.out.println("\nVehículo más barato:");
        if (barato != null) {
            System.out.println(barato);
        }

        // notificar() desde cliente y trabajador
        cli1.notificar("Su vehículo está listo.");
        t1.notificar("Tiene una nueva cita asignada.");

        // Ejemplo repostar
        coche3.repostar(10);
        System.out.println("\nCarga coche eléctrico tras repostar 10 $: " + coche3.getCargaActual());
    }
}
