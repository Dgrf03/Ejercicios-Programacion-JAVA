public class Moto extends Vehiculo {

    private int cilindros;
    private int cv;

    public Moto() {
        super();
        this.cilindros = 0;
        this.cv = 0;
    }

    public Moto(String matricula, String fechaMatriculacion, double capacidadTotal, double cargaActual, double precio, int cilindros, int cv) {
        super(matricula, fechaMatriculacion, capacidadTotal, cargaActual, precio);
        this.cilindros = cilindros;
        this.cv = cv;
    }

    public Moto(Moto m) {
        super(m);
        this.cilindros = m.cilindros;
        this.cv = m.cv;
    }

    public int getCilindros() { return cilindros; }
    public void setCilindros(int cilindros) { this.cilindros = cilindros; }

    public int getCv() { return cv; }
    public void setCv(int cv) { this.cv = cv; }

    @Override
    public String toString() {
        return super.toString() + "\nCilindros: " + cilindros + "\nCV: " + cv;
    }
}