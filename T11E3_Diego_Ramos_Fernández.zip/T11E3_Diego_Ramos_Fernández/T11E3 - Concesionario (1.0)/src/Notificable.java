public interface Notificable {
    boolean notificar(String mensaje);
}
