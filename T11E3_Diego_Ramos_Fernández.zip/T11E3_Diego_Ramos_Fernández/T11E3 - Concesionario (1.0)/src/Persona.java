public abstract class Persona implements Notificable {

    public enum TipoDocumento {
        DNI, NIE, PAS
    }

    private String nombre;
    private TipoDocumento tipoDocumento;
    private String numeroDocumento;

    public Persona() {
        this.nombre = "";
        this.tipoDocumento = TipoDocumento.DNI;
        this.numeroDocumento = "";
    }

    public Persona(String nombre, TipoDocumento tipoDocumento, String numeroDocumento) {
        this.nombre = nombre;
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
    }

    public Persona(Persona p) {
        this.nombre = p.nombre;
        this.tipoDocumento = p.tipoDocumento;
        this.numeroDocumento = p.numeroDocumento;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public TipoDocumento getTipoDocumento() { return tipoDocumento; }
    public void setTipoDocumento(TipoDocumento tipoDocumento) { this.tipoDocumento = tipoDocumento; }

    public String getNumeroDocumento() { return numeroDocumento; }
    public void setNumeroDocumento(String numeroDocumento) { this.numeroDocumento = numeroDocumento; }

    @Override
    public String toString() {
        return "\nPersona:" + "\nNombre: " + nombre + "\nTipo documento: " + tipoDocumento + "\nNúmero documento: " + numeroDocumento;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        if (obj == this) return true;
        if (obj.getClass() != this.getClass()) return false;
        Persona p = (Persona) obj;
        return this.nombre.equals(p.nombre) && this.tipoDocumento == p.tipoDocumento && this.numeroDocumento.equals(p.numeroDocumento);
    }
}
