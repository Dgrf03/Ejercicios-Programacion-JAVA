public interface Repostable {
    void repostar(double dinero);
}
