public class Trabajador extends Persona {

    private String numeroSS;
    private String fechaAntiguedad; // dd/MM/yyyy

    public Trabajador() {
        super();
        this.numeroSS = "";
        this.fechaAntiguedad = "";
    }

    public Trabajador(String nombre, TipoDocumento tipoDocumento, String numeroDocumento, String numeroSS, String fechaAntiguedad) {
        super(nombre, tipoDocumento, numeroDocumento);
        this.numeroSS = numeroSS;
        this.fechaAntiguedad = fechaAntiguedad;
    }

    public Trabajador(Trabajador t) {
        super(t);
        this.numeroSS = t.numeroSS;
        this.fechaAntiguedad = t.fechaAntiguedad;
    }

    public String getNumeroSS() { return numeroSS; }
    public void setNumeroSS(String numeroSS) { this.numeroSS = numeroSS; }

    public String getFechaAntiguedad() { return fechaAntiguedad; }
    public void setFechaAntiguedad(String fechaAntiguedad) { this.fechaAntiguedad = fechaAntiguedad; }

    @Override
    public String toString() {
        return super.toString() + "\nNúmero S.S.: " + numeroSS + "\nFecha antigüedad: " + fechaAntiguedad;
    }

    @Override
    public boolean notificar(String mensaje) {
        System.out.println("Mensaje para el trabajador: " + mensaje);
        return true;
    }
}
