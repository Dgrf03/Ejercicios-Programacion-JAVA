public abstract class Vehiculo {

    private String matricula;
    private String fechaMatriculacion;
    private double capacidadTotal;
    private double cargaActual;
    private double precio;

    public Vehiculo() {
        this.matricula = "";
        this.fechaMatriculacion = "";
        this.capacidadTotal = 0;
        this.cargaActual = 0;
        this.precio = 0;
    }

    public Vehiculo(String matricula, String fechaMatriculacion, double capacidadTotal, double cargaActual, double precio) {
        this.matricula = matricula;
        this.fechaMatriculacion = fechaMatriculacion;
        this.capacidadTotal = capacidadTotal;
        this.cargaActual = cargaActual;
        this.precio = precio;
    }

    public Vehiculo(Vehiculo v) {
        this.matricula = v.matricula;
        this.fechaMatriculacion = v.fechaMatriculacion;
        this.capacidadTotal = v.capacidadTotal;
        this.cargaActual = v.cargaActual;
        this.precio = v.precio;
    }

    public String getMatricula() { return matricula; }
    public void setMatricula(String matricula) { this.matricula = matricula; }

    public String getFechaMatriculacion() { return fechaMatriculacion; }
    public void setFechaMatriculacion(String fechaMatriculacion) { this.fechaMatriculacion = fechaMatriculacion; }

    public double getCapacidadTotal() { return capacidadTotal; }
    public void setCapacidadTotal(double capacidadTotal) { this.capacidadTotal = capacidadTotal; }

    public double getCargaActual() { return cargaActual; }
    public void setCargaActual(double cargaActual) { this.cargaActual = cargaActual; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    @Override
    public String toString() {
        return "\nVehículo:" + "\nMatrícula: " + matricula + "\nFecha matriculación: " + fechaMatriculacion + "\nCapacidad total: " + capacidadTotal + "\nCarga actual: " + cargaActual + "\nPrecio: " + precio;
    }
}
